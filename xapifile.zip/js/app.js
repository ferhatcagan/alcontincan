(function () {
  'use strict';

  const FIELD_NAME_URL      = 'https://alcon-quality.veevavault.com/ui/#complete_training/V1700000088I785';
  const FIELD_NAME_UNIQUEID = 'V-QMS-0053247';
  const COUNTDOWN_SECONDS   = 5;
  const CLIENT_ID           = 'veevatestbyferhat';
  const CLIENT_SECRET       = 'e0f7fb3bcabb89e14ddbf220a32e105abc2ee905350f374047fad1e24c3d9688';
  const VEEVA_FALLBACK_URL  = 'https://alcon-quality.veevavault.com/ui/#app/page/my-learning?ui-tab=0TB000000014021&lhpSubTab=openAssignments';

  const $ = id => document.getElementById(id);

  document.addEventListener('DOMContentLoaded', () => {
    initApp().catch(err => showError(err.message || String(err), err.detail, err.retryable));
  });

  async function initApp() {
    showState('loading');

    setStep(0, 'active');
    const params = parseLaunchParams();
    validateParams(params);
    setStep(0, 'done');

    setStep(1, 'active');
    const platformUrl = derivePlatformUrl(params.endpoint);
    const accessToken = await getAccessToken(platformUrl, params.xapi_auth_code);
    setStep(1, 'done');

    setStep(2, 'active');
    const fieldDefs = await fetchEnrollmentFieldDefs(platformUrl, accessToken);
    setStep(2, 'done');

    setStep(3, 'active');
    const enrollmentData = await fetchEnrollment(platformUrl, params.course_id, params.user_id, accessToken);
    setStep(3, 'done');

    setStep(4, 'active');
    const { veevaUrl, uniqueId, isFallback } = extractVeevaFields(enrollmentData, fieldDefs);
    setStep(4, 'done');

    showReadyState(veevaUrl, uniqueId, isFallback);
  }

  function parseLaunchParams() {
    const p = {};
    window.location.search.slice(1).split('&').forEach(part => {
      const idx = part.indexOf('=');
      if (idx === -1) return;
      p[decodeURIComponent(part.slice(0, idx))] = decodeURIComponent(part.slice(idx + 1));
    });
    return p;
  }

  function validateParams(p) {
    const missing = ['endpoint', 'xapi_auth_code', 'course_id', 'user_id'].filter(k => !p[k]);
    if (missing.length) {
      throw Object.assign(
        new Error(`Missing required xAPI launch parameter(s): ${missing.join(', ')}`),
        { detail: 'Ensure this package is launched from Docebo with the standard xAPI parameters.' }
      );
    }
  }

  function derivePlatformUrl(endpoint) {
    try {
      return new URL(endpoint).origin;
    } catch {
      return endpoint.replace(/\/(tcapi|api|lrs)\/?.*$/i, '').replace(/\/$/, '');
    }
  }

  async function getAccessToken(platformUrl, authCode) {
    const tokenUrl = `${platformUrl}/oauth2/token`;
    let res;
    try {
      res = await fetch(tokenUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          grant_type: 'authorization_code',
          client_id: CLIENT_ID,
          client_secret: CLIENT_SECRET,
          code: authCode
        }).toString()
      });
    } catch (err) {
      throw Object.assign(new Error('Network error while obtaining access token.'), { detail: err.message });
    }

    let json;
    try { json = await res.json(); } catch { json = {}; }

    if (!res.ok || !json.access_token) {
      const msg = json.error_description || json.message || json.error || `HTTP ${res.status}`;
      throw Object.assign(
        new Error('Your session has expired. Please go back to Docebo and relaunch the package to start a new session.'),
        { detail: `Token exchange failed (${msg}) - POST ${tokenUrl} -> ${res.status}`, retryable: false }
      );
    }

    return json.access_token;
  }

  async function fetchEnrollmentFieldDefs(platformUrl, accessToken) {
    let res;
    try {
      res = await fetch(`${platformUrl}/manage/v1/enrollment_fields`, {
        headers: { 'Authorization': `Bearer ${accessToken}`, 'Accept': 'application/json' }
      });
    } catch {
      return [];
    }

    let json;
    try { json = await res.json(); } catch { json = {}; }

    if (!res.ok) return [];

    const items = json?.data?.items ?? json?.data ?? json?.items ?? json;
    return Array.isArray(items) ? items : [];
  }

  async function fetchEnrollment(platformUrl, courseId, userId, accessToken) {
    const url = `${platformUrl}/learn/v1/enrollments/${courseId}/${userId}`;
    let res;
    try {
      res = await fetch(url, {
        headers: { 'Authorization': `Bearer ${accessToken}`, 'Accept': 'application/json' }
      });
    } catch (err) {
      throw Object.assign(new Error('Network error while fetching enrollment data.'), { detail: err.message });
    }

    let json;
    try { json = await res.json(); } catch { json = {}; }

    if (!res.ok) {
      const msg = json.message || json.error || `HTTP ${res.status}`;
      throw Object.assign(new Error(`Enrollment API error: ${msg}`), { detail: `GET ${url} -> ${res.status}` });
    }

    return json;
  }

  function extractVeevaFields(apiResponse, fieldDefs) {
    const record = apiResponse?.data?.records ?? apiResponse?.data ?? apiResponse;
    if (!record) throw new Error('Unexpected enrollment API response structure.');

    const fields = record.enrollment_fields;
    if (!fields || typeof fields !== 'object' || Object.keys(fields).length === 0) {
      return { veevaUrl: null, uniqueId: null, isFallback: true };
    }

    let veevaUrl = null;
    let uniqueId = null;

    if (Array.isArray(fieldDefs) && fieldDefs.length) {
      const nameOf = f => (f.title || f.name || '').trim();
      const urlDef = fieldDefs.find(f => nameOf(f) === FIELD_NAME_URL);
      const uidDef = fieldDefs.find(f => nameOf(f) === FIELD_NAME_UNIQUEID);
      if (urlDef) veevaUrl = fields[String(urlDef.id)] || null;
      if (uidDef) uniqueId = fields[String(uidDef.id)] || null;
    }

    if (!veevaUrl && !uniqueId) {
      const keys = Object.keys(fields).filter(k => /^\d+$/.test(k)).sort((a, b) => Number(a) - Number(b));
      if (keys.length >= 2) {
        uniqueId = fields[keys[keys.length - 2]] || null;
        veevaUrl = fields[keys[keys.length - 1]] || null;
      } else if (keys.length === 1) {
        const v = fields[keys[0]];
        if (/^https?:\/\//i.test(v)) veevaUrl = v;
        else uniqueId = v;
      }
    }

    if (veevaUrl && uniqueId && !/^https?:\/\//i.test(veevaUrl) && /^https?:\/\//i.test(uniqueId)) {
      [veevaUrl, uniqueId] = [uniqueId, veevaUrl];
    }

    if (!veevaUrl) return { veevaUrl: null, uniqueId: uniqueId || null, isFallback: true };

    return { veevaUrl, uniqueId, isFallback: false };
  }

  function showState(name) {
    document.querySelectorAll('.state').forEach(el => el.classList.remove('active'));
    const target = $(`state-${name}`);
    if (target) target.classList.add('active');
  }

  function setStep(index, state) {
    const steps = document.querySelectorAll('.loading-steps li');
    if (!steps[index]) return;
    steps[index].classList.remove('done', 'active');
    if (state) steps[index].classList.add(state);
  }

  function showReadyState(veevaUrl, uniqueId, isFallback) {
    const destination = veevaUrl || VEEVA_FALLBACK_URL;

    if (isFallback) {
      $('ready-title').textContent = 'No specific assignment linked yet';
      $('ready-sub').innerHTML =
        'Your training assignment URL has not been set up for this enrollment.<br>' +
        'Please visit <strong>Veeva Quality Docs</strong> to view your pending training assignments.';
      const box = document.querySelector('.assignment-box');
      if (box) box.style.opacity = '0.75';
    } else {
      $('ready-title').textContent = 'Your training assignment is ready';
      $('ready-sub').innerHTML =
        'You are being redirected to Veeva Quality Docs to complete<br>your assigned training document.';
    }

    $('field-url').textContent = destination;
    $('field-uid').textContent = uniqueId || '-';

    const btn = $('redirect-btn');
    btn.href = destination;
    btn.setAttribute('target', '_blank');
    btn.setAttribute('rel', 'noopener noreferrer');
    $('redirect-btn-label').textContent = isFallback
      ? 'Go to Veeva Training Assignments'
      : 'Open Training Assignment Now';

    showState('ready');
    startCountdown(destination);
  }

  function startCountdown(url) {
    let remaining = COUNTDOWN_SECONDS;
    const label = $('countdown-label');
    const bar   = $('countdown-progress');

    function tick() {
      if (remaining <= 0) {
        window.open(url, '_blank', 'noopener,noreferrer');
        return;
      }
      label.textContent = `Redirecting in ${remaining} second${remaining !== 1 ? 's' : ''}...`;
      bar.style.width   = `${(remaining / COUNTDOWN_SECONDS) * 100}%`;
      remaining--;
      setTimeout(tick, 1000);
    }

    tick();
  }

  function showError(message, detail, retryable) {
    $('error-message').textContent = message;
    $('error-detail').textContent  = detail || '';
    showState('error');

    const retryBtn = $('retry-btn');
    const fresh    = retryBtn.cloneNode(true);
    retryBtn.parentNode.replaceChild(fresh, retryBtn);

    if (retryable === false) {
      fresh.textContent = 'Go Back to Docebo to Relaunch';
      fresh.addEventListener('click', () => {
        if (window.history.length > 1) window.history.back();
        else window.close();
      });
    } else {
      fresh.addEventListener('click', () => {
        showState('loading');
        initApp().catch(err => showError(err.message || String(err), err.detail, err.retryable));
      });
    }
  }

})();
