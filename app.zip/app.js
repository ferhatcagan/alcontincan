const contextEl = document.getElementById("context");
const assignmentsEl = document.getElementById("assignments");
const statusEl = document.getElementById("status");
const countEl = document.getElementById("count");
const consentStatusEl = document.getElementById("consent-status");
const consentCheckbox = document.getElementById("consent-checkbox");
const consentButton = document.getElementById("consent-button");

const DEBUG = true;
function logStep(message, details) {
  if (!DEBUG) {
    return;
  }
  if (details) {
    console.log(`[Alcon POC] ${message}`, details);
  } else {
    console.log(`[Alcon POC] ${message}`);
  }
}

const params = new URLSearchParams(window.location.search);
let tincan;
let tincanRegistration;
let mainActivityId;
let currentAssignments = [];

function initTinCan() {
  if (!window.TinCan) {
    logStep("TinCanJS not loaded.");
    return;
  }
  try {
    tincan = new TinCan({ url: window.location.href });
    if (tincan.registration) {
      tincanRegistration = tincan.registration;
    }
    if (tincan.activity && tincan.activity.id) {
      mainActivityId = tincan.activity.id;
    }
    logStep("TinCan initialized.", {
      registration: tincanRegistration || null,
      activityId: mainActivityId || null,
      hasRecordStore: Boolean(tincan.recordStores && tincan.recordStores.length),
    });
  } catch (error) {
    tincan = null;
    logStep("TinCan initialization failed.", { error: error.message });
  }
}

function renderContext(data) {
  const lines = [
    { label: "Course Code", value: data.course_code || "" },
    { label: "Course Id", value: data.course_id || "" },
    { label: "Username", value: data.username || "" },
    { label: "User Id", value: data.user_id || "" },
    { label: "Auth Code", value: data.auth_code || "" },
  ];
  const note = `
    <details class="hash-note">
      <summary>Hash validation details</summary>
      <div class="hash-body">
        <div class="hash-formula">
          <strong>Formula:</strong>
          <code>SHA-256(course_code,course_id,username,user_id,auth_code)</code>
        </div>
        <div class="hash-values">
          <div>Received: <code>${data.hash_received || ""}</code></div>
          <div>Calculated: <code>${data.hash_calculated || ""}</code></div>
        </div>
      </div>
    </details>
  `;
  contextEl.innerHTML = `
    <div class="context-grid">
      ${lines
        .map(
          (line) =>
            `<div class="context-item"><span>${line.label}:</span> <strong>${line.value}</strong></div>`
        )
        .join("")}
    </div>
    ${note}
  `;
}

function renderAssignments(assignments, message) {
  currentAssignments = assignments;
  logStep("Rendering assignments.", {
    count: assignments.length,
    statuses: assignments.map((item) => ({ id: item.id, status: item.status })),
  });
  countEl.textContent = assignments.length;
  if (!assignments.length) {
    assignmentsEl.innerHTML =
      `<p class="status">${
        message || "No assignments were found for this learner."
      }</p>`;
    updateConsentState();
    return;
  }

  assignmentsEl.innerHTML = assignments
    .map((assignment) => {
      const isOpened = assignment.status === "opened" || assignment.status === "completed";
      const isCompleted = assignment.status === "completed";
      return `
        <div class="assignment ${isCompleted ? "completed" : ""}">
          <div>
            <h3>${assignment.title}</h3>
            <p>
              <span class="badge">${assignment.status}</span>
              Due ${assignment.dueDate}
            </p>
          </div>
          <a class="${isCompleted ? "button completed" : isOpened ? "button opened" : "button"}" href="${assignment.href}" target="_blank" rel="noopener" data-id="${assignment.id}">
            ${isCompleted ? "Completed" : isOpened ? "Opened" : "Open"}
          </a>
        </div>
      `;
    })
    .join("");

  assignmentsEl.querySelectorAll("a[data-id]").forEach((link) => {
    link.addEventListener("click", () => {
      const assignmentId = link.dataset.id;
      if (!link.classList.contains("opened")) {
        link.classList.add("opened");
        link.textContent = "Opened";
        const badge = link.closest(".assignment").querySelector(".badge");
        if (badge) {
          badge.textContent = "opened";
        }
        currentAssignments = currentAssignments.map((item) =>
          item.id === assignmentId ? { ...item, status: "opened" } : item
        );
        updateConsentState();
      }
      sendClickStatement(assignmentId, link.href);
    });
  });

  updateConsentState();
}

function updateConsentState() {
  const total = currentAssignments.length;
  const openedCount = currentAssignments.filter(
    (item) => item.status === "opened"
  ).length;
  const allOpened = total > 0 && openedCount === total;

  logStep("Consent state updated.", { total, openedCount, allOpened });

  consentCheckbox.disabled = !allOpened;
  consentButton.disabled = !allOpened || !consentCheckbox.checked;
  consentStatusEl.textContent = allOpened ? "Ready" : "Locked";
}

function readLaunchParams() {
  const raw = Object.fromEntries(params.entries());
  return raw;
}

function getApiBase() {
  return params.get("api_base") || window.API_BASE || window.location.origin;
}

async function loadAssignments() {
  const launch = readLaunchParams();
  logStep("Launch params received.", launch);
  if (!launch.hash || !launch.username || !launch.course_code) {
    statusEl.textContent =
      "Missing launch parameters. Ensure Docebo passes hash, username, and course_code.";
    logStep("Missing required launch params.");
    return;
  }

  statusEl.textContent = "Validating request…";
  const query = new URLSearchParams(launch);

  const apiBase = getApiBase();
  logStep("Requesting assignments.", { apiBase });
  const response = await fetch(`${apiBase}/api/deeplink?${query.toString()}`, {
    headers: {
      "ngrok-skip-browser-warning": "1",
    },
  });
  const data = await response.json();
  logStep("Assignments response.", { ok: response.ok, data });
  if (!response.ok || !data.ok) {
    statusEl.textContent = "Hash validation failed. Contact support.";
    contextEl.textContent = "";
    assignmentsEl.textContent = "";
    return;
  }

  renderContext(data);
  renderAssignments(data.assignments || [], data.message);
  statusEl.textContent = "Assignments ready. Click to open.";
}

async function sendClickStatement(assignmentId, assignmentUrl) {
  const actorRaw = params.get("actor");

  if (!actorRaw) {
    logStep("Missing actor parameter. Cannot send statement.");
    return;
  }

  let actor;
  try {
    actor = JSON.parse(actorRaw);
    if (Array.isArray(actor.mbox)) {
      actor.mbox = actor.mbox[0];
    }
    if (Array.isArray(actor.name)) {
      actor.name = actor.name[0];
    }
  } catch (error) {
    logStep("Failed to parse actor.", { error: error.message });
    return;
  }

  const statementData = {
    actor,
    verb: {
      id: "http://adlnet.gov/expapi/verbs/experienced",
      display: { "en-US": "opened" },
    },
    object: {
      id: assignmentUrl,
      definition: {
        name: { "en-US": `Veeva QD Assignment ${assignmentId}` },
        type: "http://adlnet.gov/expapi/activities/link",
      },
    },
    context: {
      platform: "Docebo",
      registration: tincanRegistration || undefined,
      contextActivities: {
        category: [
          {
            id: "http://example.com/xapi/qdocs",
          },
        ],
      },
    },
    timestamp: new Date().toISOString(),
  };

  if (tincan && tincan.recordStores && tincan.recordStores.length > 0) {
    const statement = new TinCan.Statement(statementData);
    logStep("Sending statement to LRS.", statementData);
    tincan.sendStatement(statement, () => {
      statusEl.textContent = "Statement sent to LRS.";
      logStep("Statement sent to LRS.");
    });
    return;
  }
  statusEl.textContent = "TinCan not initialized. Cannot send statement.";
  logStep("TinCan not initialized. Statement not sent.");
}

function handleConsentChange() {
  consentButton.disabled = !consentCheckbox.checked;
  logStep("Consent checkbox changed.", { checked: consentCheckbox.checked });
}

function handleConsentSubmit() {
  if (!tincan || !tincan.recordStores || tincan.recordStores.length === 0) {
    statusEl.textContent = "TinCan not initialized. Cannot complete.";
    logStep("Cannot submit completion. TinCan not initialized.");
    return;
  }
  const activityId =
    mainActivityId || params.get("activity_id") || "http://example.com/xapi/package";
  const statement = new TinCan.Statement({
    actor: tincan.actor,
    verb: {
      id: "http://adlnet.gov/expapi/verbs/completed",
      display: { "en-US": "completed" },
    },
    object: {
      id: activityId,
      definition: {
        name: { "en-US": "Alcon Quality Docs Deep Link POC" },
        type: "http://adlnet.gov/expapi/activities/module",
      },
    },
    context: tincanRegistration ? { registration: tincanRegistration } : undefined,
    result: { completion: true, success: true },
    timestamp: new Date().toISOString(),
  });
  logStep("Sending completion statement.", {
    activityId,
    registration: tincanRegistration || null,
  });
  tincan.sendStatement(statement, () => {
    statusEl.textContent = "Completion sent to LRS.";
    currentAssignments = currentAssignments.map((item) => ({
      ...item,
      status: "completed",
    }));
    renderAssignments(currentAssignments, "");
    consentButton.disabled = true;
    consentCheckbox.disabled = true;
    consentStatusEl.textContent = "Completed";
    logStep("Completion statement sent and UI updated.");
  });
}

consentCheckbox?.addEventListener("change", handleConsentChange);
consentButton?.addEventListener("click", handleConsentSubmit);

initTinCan();
loadAssignments();
